# Gym Tracker v2
Native Kotlin + Jetpack Compose Android app.

Simple by design:
- Today: select exercises completed + one daily note
- History: see exactly what was done each day
- Exercises: create/edit/delete workout schedules
- Starter Push/Pull/Legs schedules
- Local persistent offline storage using Android DataStore
- No login, server, API, or internet required
- Java/Kotlin JVM target 17 configured
