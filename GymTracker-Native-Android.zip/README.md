# Gym Tracker — Native Android

This is a real Kotlin + Jetpack Compose Android application, not an HTML/WebView app.

## Features
- Today workout screen
- Push / Pull / Legs / Other
- Exercise sets, reps and weight
- Cardio
- Workout rating
- Notes
- Workout history
- Basic progress statistics
- Offline/local app data for the current app session

## Build
Open this project in an Android build environment that supports Gradle/Android SDK.
The app module is `app`.

Application ID:
`com.sahil.gymtracker`

Version:
`1.0`


Build configuration fixed for Java/Kotlin JVM target 17.
