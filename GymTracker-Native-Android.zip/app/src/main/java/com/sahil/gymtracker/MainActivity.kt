package com.sahil.gymtracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

data class SetLog(val reps: String = "", val weight: String = "")
data class ExerciseLog(
    val name: String,
    val sets: List<SetLog>
)
data class Workout(
    val id: Long,
    val date: String,
    val bodyPart: String,
    val exercises: List<ExerciseLog>,
    val cardio: String,
    val rating: Int,
    val notes: String
)

class GymViewModel : ViewModel() {
    private val _workouts = MutableStateFlow<List<Workout>>(emptyList())
    val workouts = _workouts.asStateFlow()

    private val defaultExercises = listOf(
        "Bench Press", "Incline Dumbbell Press", "Shoulder Press",
        "Lateral Raise", "Triceps Pushdown", "Lat Pulldown",
        "Seated Row", "Barbell Curl", "Leg Press", "Leg Curl",
        "Leg Extension", "Calf Raise"
    )

    fun exercises() = defaultExercises

    fun addWorkout(workout: Workout) {
        _workouts.value = listOf(workout) + _workouts.value
    }

    fun deleteWorkout(id: Long) {
        _workouts.value = _workouts.value.filterNot { it.id == id }
    }

    fun lastFor(exercise: String): ExerciseLog? =
        _workouts.value.flatMap { it.exercises }.lastOrNull { it.name == exercise }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp() }
    }
}

@Composable
fun GymTrackerApp(vm: GymViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF66BB6A),
            background = Color(0xFF0B0F14),
            surface = Color(0xFF121820)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF10151C)) {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Today, null) }, label = { Text("Today") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("History") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text("Progress") })
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (tab) {
                    0 -> TodayScreen(vm)
                    1 -> HistoryScreen(vm)
                    2 -> ProgressScreen(vm)
                }
            }
        }
    }
}

@Composable
fun TodayScreen(vm: GymViewModel) {
    var bodyPart by remember { mutableStateOf("Push") }
    var cardio by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var rating by remember { mutableIntStateOf(5) }
    var exercises by remember {
        mutableStateOf(
            listOf(
                ExerciseLog("Bench Press", listOf(SetLog(), SetLog(), SetLog())),
                ExerciseLog("Shoulder Press", listOf(SetLog(), SetLog(), SetLog())),
                ExerciseLog("Lateral Raise", listOf(SetLog(), SetLog(), SetLog())),
                ExerciseLog("Triceps Pushdown", listOf(SetLog(), SetLog(), SetLog()))
            )
        )
    }
    var saved by remember { mutableStateOf(false) }

    fun updateSet(ei: Int, si: Int, reps: String, weight: String) {
        exercises = exercises.toMutableList().also { list ->
            val e = list[ei]
            val sets = e.sets.toMutableList()
            sets[si] = SetLog(reps, weight)
            list[ei] = e.copy(sets = sets)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("GYM TRACKER", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(today(), color = Color.LightGray)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Push", "Pull", "Legs", "Other").forEach {
                    FilterChip(selected = bodyPart == it, onClick = { bodyPart = it }, label = { Text(it) })
                }
            }
        }
        items(exercises.indices.toList()) { ei ->
            val ex = exercises[ei]
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(ex.name, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Set", Modifier.width(34.dp))
                        Text("Reps", Modifier.weight(1f))
                        Text("Weight kg", Modifier.weight(1f))
                    }
                    ex.sets.forEachIndexed { si, set ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("${si+1}", Modifier.width(34.dp))
                            OutlinedTextField(
                                value = set.reps, onValueChange = { updateSet(ei, si, it, set.weight) },
                                modifier = Modifier.weight(1f), singleLine = true
                            )
                            OutlinedTextField(
                                value = set.weight, onValueChange = { updateSet(ei, si, set.reps, it) },
                                modifier = Modifier.weight(1f), singleLine = true
                            )
                        }
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = cardio, onValueChange = { cardio = it },
                label = { Text("Cardio (e.g. 15 min treadmill)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Text("Workout rating: $rating/10")
            Slider(value = rating.toFloat(), onValueChange = { rating = it.toInt().coerceIn(1,10) }, valueRange = 1f..10f, steps = 8)
        }
        item {
            OutlinedTextField(
                value = notes, onValueChange = { notes = it },
                label = { Text("Notes — how did you feel?") },
                modifier = Modifier.fillMaxWidth(), minLines = 2
            )
        }
        item {
            Button(
                onClick = {
                    vm.addWorkout(
                        Workout(System.currentTimeMillis(), today(), bodyPart, exercises, cardio, rating, notes)
                    )
                    saved = true
                },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(if (saved) "Workout Saved ✓" else "Save Workout")
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: GymViewModel) {
    val workouts by vm.workouts.collectAsState()
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        contentPadding = PaddingValues(vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("WORKOUT HISTORY", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
        }
        if (workouts.isEmpty()) {
            item { Text("No workouts saved yet. Complete today's workout and it will appear here.", color = Color.LightGray) }
        }
        items(workouts, key = { it.id }) { w ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(w.bodyPart, fontWeight = FontWeight.Bold)
                        Text(w.date, color = Color.LightGray)
                    }
                    Text("${w.exercises.size} exercises  •  Rating ${w.rating}/10")
                    if (w.cardio.isNotBlank()) Text("Cardio: ${w.cardio}")
                    if (w.notes.isNotBlank()) Text("“${w.notes}”", color = Color.LightGray)
                    TextButton(onClick = { vm.deleteWorkout(w.id) }) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(vm: GymViewModel) {
    val workouts by vm.workouts.collectAsState()
    val totalSets = workouts.sumOf { w -> w.exercises.sumOf { it.sets.size } }
    val avgRating = if (workouts.isEmpty()) 0 else workouts.sumOf { it.rating } / workouts.size
    val bodyCounts = workouts.groupingBy { it.bodyPart }.eachCount()

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("PROGRESS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("See what you're actually doing over time.", color = Color.LightGray)
        }
        item { StatCard("Total workouts", workouts.size.toString()) }
        item { StatCard("Total sets logged", totalSets.toString()) }
        item { StatCard("Average workout rating", if (workouts.isEmpty()) "—" else "$avgRating/10") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Body-part frequency", fontWeight = FontWeight.Bold)
                    if (bodyCounts.isEmpty()) Text("Start logging workouts to see your split.")
                    bodyCounts.forEach { (part, count) -> Text("$part: $count workout(s)") }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Latest workouts", fontWeight = FontWeight.Bold)
                    workouts.take(5).forEach { Text("${it.date}  •  ${it.bodyPart}") }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

fun today(): String = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date())
