package com.sahil.gymtracker

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.*

private val Context.store by preferencesDataStore("gym_data")
private val LOGS = stringPreferencesKey("logs")
private val SCHEDULES = stringPreferencesKey("schedules")

@Serializable data class DayLog(val date:String,val exercises:List<String>,val note:String="")
@Serializable data class Schedule(val name:String,val exercises:List<String>)

class Repo(private val c:Context){
    suspend fun logs():List<DayLog> = c.store.data.first()[LOGS]?.let{runCatching{Json.decodeFromString<List<DayLog>>(it)}.getOrDefault(emptyList())}?:emptyList()
    suspend fun schedules():List<Schedule> = c.store.data.first()[SCHEDULES]?.let{runCatching{Json.decodeFromString<List<Schedule>>(it)}.getOrDefault(emptyList())}?:emptyList()
    suspend fun saveLogs(v:List<DayLog>){c.store.edit{it[LOGS]=Json.encodeToString(v)}}
    suspend fun saveSchedules(v:List<Schedule>){c.store.edit{it[SCHEDULES]=Json.encodeToString(v)}}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(this)}}
}

@Composable fun App(c:Context){
    val repo=remember{Repo(c)}; val scope=rememberCoroutineScope()
    var logs by remember{mutableStateOf(emptyList<DayLog>())}
    var schedules by remember{mutableStateOf(emptyList<Schedule>())}
    var tab by remember{mutableIntStateOf(0)}
    LaunchedEffect(Unit){logs=repo.logs();schedules=repo.schedules()}
    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF66BB6A),background=Color(0xFF0B0F14),surface=Color(0xFF121820))){
        Scaffold(containerColor=MaterialTheme.colorScheme.background,bottomBar={
            NavigationBar(containerColor=Color(0xFF10151C)){
                NavigationBarItem(tab==0,{tab=0},{Icon(Icons.Default.Today,null)},{Text("Today")})
                NavigationBarItem(tab==1,{tab=1},{Icon(Icons.Default.History,null)},{Text("History")})
                NavigationBarItem(tab==2,{tab=2},{Icon(Icons.Default.FitnessCenter,null)},{Text("Exercises")})
            }
        }){p->Box(Modifier.padding(p)){when(tab){
            0->Today(repo,logs,schedules){logs=it}
            1->History(logs)
            2->Exercises(repo,schedules){schedules=it}
        }}}
    }
}

fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
fun pretty(d:String)=runCatching{SimpleDateFormat("EEE, dd MMM",Locale.getDefault()).format(SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).parse(d)!!)}.getOrDefault(d)

val defaults=listOf("Bench Press","Shoulder Press","Lateral Raise","Triceps Pushdown","Lat Pulldown","Seated Row","Face Pull","Biceps Curl","Leg Press","Leg Curl","Leg Extension","Calf Raise")

@Composable fun Today(repo:Repo,logs:List<DayLog>,schedules:List<Schedule>,onSave:(List<DayLog>)->Unit){
    val scope=rememberCoroutineScope(); val current=logs.firstOrNull{it.date==today()}
    var selected by remember(current){mutableStateOf(current?.exercises?.toSet()?:emptySet())}
    var note by remember(current){mutableStateOf(current?.note?:"")}
    var chosen by remember{mutableStateOf<Schedule?>(null)};var picker by remember{mutableStateOf(false)}
    val exercises=schedules.flatMap{it.exercises}.distinct().ifEmpty{defaults}
    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(vertical=18.dp)){
        item{Text("TODAY",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(SimpleDateFormat("EEEE, dd MMMM",Locale.getDefault()).format(Date()),color=Color.LightGray)}
        if(schedules.isNotEmpty())item{OutlinedButton({picker=true},Modifier.fillMaxWidth()){Icon(Icons.Default.PlaylistAdd,null);Spacer(Modifier.width(8.dp));Text(chosen?.name?:"Use a schedule")}}
        item{Text("Exercises I did",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)}
        items(exercises){e->FilterChip(selected.contains(e),{selected=selected.toMutableSet().also{if(!it.add(e))it.remove(e)}},{Text(e)},modifier=Modifier.fillMaxWidth())}
        item{OutlinedTextField(note,{note=it},label={Text("Daily note")},placeholder={Text("Anything worth remembering today?")},modifier=Modifier.fillMaxWidth(),minLines=3)}
        item{Button({val v=logs.filterNot{it.date==today()}+DayLog(today(),selected.toList().sorted(),note);scope.launch{repo.saveLogs(v)};onSave(v)},Modifier.fillMaxWidth().height(52.dp)){Icon(Icons.Default.Save,null);Spacer(Modifier.width(8.dp));Text("Save today")}}
    }
    if(picker)AlertDialog(onDismissRequest={picker=false},title={Text("Choose schedule")},text={Column{ schedules.forEach{s->TextButton({chosen=s;selected=s.exercises.toSet();picker=false},Modifier.fillMaxWidth()){Text(s.name)}}}},confirmButton={TextButton({picker=false}){Text("Cancel")}})
}

@Composable fun History(logs:List<DayLog>){
    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(vertical=18.dp)){
        item{Text("HISTORY",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("${logs.size} saved workout day(s)",color=Color.LightGray)}
        if(logs.isEmpty())item{Text("Your saved days will appear here.")}
        items(logs.sortedByDescending{it.date}){l->Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text(pretty(l.date),fontWeight=FontWeight.Bold);Text(if(l.exercises.isEmpty())"No exercises logged" else l.exercises.joinToString("  •  "));if(l.note.isNotBlank())Text("“${l.note}”",color=Color.LightGray)}}}
    }
}

@Composable fun Exercises(repo:Repo,schedules:List<Schedule>,onChange:(List<Schedule>)->Unit){
    val scope=rememberCoroutineScope();var editor by remember{mutableStateOf<Schedule?>(null)};var adding by remember{mutableStateOf(false)};var deleting by remember{mutableStateOf<Schedule?>(null)}
    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(vertical=18.dp)){
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("EXERCISES",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Create your workout schedules",color=Color.LightGray)};IconButton({editor=null;adding=true}){Icon(Icons.Default.Add,null)}}}
        items(schedules){s->Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(s.name,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium);Row{IconButton({editor=s;adding=true}){Icon(Icons.Default.Edit,null)};IconButton({deleting=s}){Icon(Icons.Default.Delete,null)}}};Text(s.exercises.joinToString("  •  "),color=Color.LightGray)}}}
        item{Text("Good starter schedules",fontWeight=FontWeight.Bold)}
        item{Text("Push  •  Bench Press • Shoulder Press • Lateral Raise • Triceps Pushdown",color=Color.LightGray);Text("Pull  •  Lat Pulldown • Seated Row • Face Pull • Biceps Curl",color=Color.LightGray);Text("Legs  •  Leg Press • Leg Curl • Leg Extension • Calf Raise",color=Color.LightGray)}
        item{Button({val v=(schedules+listOf(Schedule("Push",defaults.take(4)),Schedule("Pull",defaults.slice(4..7)),Schedule("Legs",defaults.slice(8..11)))).distinctBy{it.name};scope.launch{repo.saveSchedules(v)};onChange(v)},Modifier.fillMaxWidth()){Text("Add starter schedules")}}
    }
    if(adding)ScheduleEditor(editor,{adding=false}){s->val v=if(editor==null)schedules+s else schedules.map{if(it.name==editor!!.name)s else it};scope.launch{repo.saveSchedules(v)};onChange(v);adding=false}
    deleting?.let{s->AlertDialog(onDismissRequest={deleting=null},title={Text("Delete ${s.name}?")},text={Text("Past workout history will stay safe.")},confirmButton={TextButton({val v=schedules.filterNot{it.name==s.name};scope.launch{repo.saveSchedules(v)};onChange(v);deleting=null}){Text("Delete")}},dismissButton={TextButton({deleting=null}){Text("Cancel")}})}
}

@Composable fun ScheduleEditor(old:Schedule?,dismiss:()->Unit,save:(Schedule)->Unit){
    var name by remember{mutableStateOf(old?.name?:"")};var ex by remember{mutableStateOf(old?.exercises?.joinToString("
")?:"")}
    AlertDialog(onDismissRequest=dismiss,title={Text(if(old==null)"New schedule" else "Edit schedule")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(name,{name=it},label={Text("Schedule name")},singleLine=true);OutlinedTextField(ex,{ex=it},label={Text("Exercises — one per line")},minLines=6)}},confirmButton={TextButton({val list=ex.lines().map{it.trim()}.filter{it.isNotBlank()};if(name.isNotBlank()&&list.isNotEmpty())save(Schedule(name.trim(),list))}){Text("Save")}},dismissButton={TextButton(dismiss){Text("Cancel")}})
}
